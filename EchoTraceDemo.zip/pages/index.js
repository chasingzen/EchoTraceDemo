import EchoTraceHomePage from '../components/EchoTraceHomePage';

export default function Home() {
  return <EchoTraceHomePage />;
}